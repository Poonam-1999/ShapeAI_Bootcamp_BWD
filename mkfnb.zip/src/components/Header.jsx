import React from "react";
function Header(){
  return <div>
    <header>ShapeAI</header>
  </div>;
}
export default Header;