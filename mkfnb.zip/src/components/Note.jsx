import React from 'react'
function Note() {
  
  return (
    <div className="Note">
      <h1>javascript and React.js</h1>
      <p>
        This was an amazing Bootcamp By shaurya sir we covered everything from
        Scrath including javascript and react .js,html
      </p>
    </div>
  )
}
export default Note
